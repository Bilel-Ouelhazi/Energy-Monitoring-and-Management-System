import pymongo as md
from datetime import date, datetime
import serial
import time


com = None


day = date.today()


port = "COM3"
try:
    com = serial.Serial(port, 115200, timeout=1)
except Exception:
    print("Problème de connexion série ")

if com:
    try:
        client = md.MongoClient("localhost", 27017, ServerSelectionTimeoutMS=5000)
        Dblist = client.list_database_names()
        print(Dblist)
        if 'STEG_BASE' in Dblist:
            Dbclient = client.STEG_BASE
            print(Dbclient)
            listCollect = Dbclient.list_collection_names()
            if "tension" in listCollect:
                table = Dbclient.get_collection("tension")
            else:
                print("Table introuvable")
        else:
            print("Base de données introuvable")


        config_collection = Dbclient.get_collection("config")


        max_value_document = config_collection.find_one(sort=[("max_value", 1)])
        max_value = max_value_document["max_value"]

        print("Max value retrieved from config:", max_value)

    except Exception as e:
        print("Erreur: ", str(e))
else:
    print("Serial connection failed. Exiting program.")
    exit()

while True:

    line = com.readline().decode('utf-8').strip()


    parts = line.split(":")
    if len(parts) == 2:
        type_data, data = parts
    else:
        print("Invalid data format:", line)
        continue

    # Time
    now = datetime.now()
    month = now.strftime("%m")
    year = now.strftime("%Y")
    date_time = now.strftime("%d-%m-%Y:%H:%M:%S")

    # Prepare document
    document = {"type": type_data, "data": data, "date": date_time, "month": month, "year": year}


    if type_data == "energie":
        if "energie" in listCollect:
            energie_table = Dbclient.get_collection("energie")
            energie_table.insert_one(document)
        else:
            print("Collection 'energie' not found.")
    elif type_data == "intensite":
        if "intensite" in listCollect:
            intensite_table = Dbclient.get_collection("intensite")
            intensite_table.insert_one(document)
        else:
            print("Collection 'intensite' not found.")
    elif type_data == "puissance":
        if "puissance" in listCollect:
            puissance_table = Dbclient.get_collection("puissance")
            puissance_table.insert_one(document)
        else:
            print("Collection 'puissance' not found.")
    elif type_data == "tension":
        if "tension" in listCollect:
            tension_table = Dbclient.get_collection("tension")
            tension_table.insert_one(document)
        else:
            print("Collection 'tension' not found.")
    else:
        print("Invalid type:", type_data)

    time.sleep(5)


    try:
        com.write(str(max_value).encode())
        print("Max value sent to ESP32:", max_value)
    except Exception as e:
        print("Failed to send max value to ESP32:", str(e))

    time.sleep(5)

