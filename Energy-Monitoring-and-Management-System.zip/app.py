
from flask import Flask, render_template, jsonify, request, redirect, url_for
from pymongo import MongoClient
import datetime


app = Flask(__name__)


client = MongoClient('mongodb://localhost:27017/')
db = client['STEG_BASE']
puissance_collection = db['puissance']
intensite_collection = db['intensite']
config_collection = db['config']
energie_collection = db['energie']



# Login route
@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'user' and password == 'user':
            return redirect(url_for('interface2'))
        elif username == 'admin' and password == 'admin':
            return redirect(url_for('user_list'))
        else:
            error = 'Invalid credentials. Please try again.'
    return render_template('index.html', error=error)






# Interface route
@app.route('/interface')
def interface():

    today_date = datetime.datetime.now().strftime('%d-%m-%Y')

    today_data = puissance_collection.find({
        'date': {'$regex': '^' + today_date}
    })

    labels_daily = []
    data_daily = []
    for entry in today_data:
        labels_daily.append(entry['date'])
        data_daily.append(entry['data'])


    monthly_data = puissance_collection.aggregate([
        {"$group": {"_id": "$month", "total": {"$sum": {"$toInt": "$data"}}}}
    ])

    labels_monthly = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
    data_monthly = [0] * 12

    for entry in monthly_data:
        month_index = int(entry['_id']) - 1
        data_monthly[month_index] = entry['total']


    yearly_data = puissance_collection.aggregate([
        {"$group": {"_id": "$year", "total": {"$sum": {"$toInt": "$data"}}}}
    ])

    labels_yearly = ['2024', '2025', '2026', '2027']
    data_yearly = [0] * 4

    for entry in yearly_data:
        year_index = int(entry['_id']) - 2024
        data_yearly[year_index] = entry['total']


    last_intensite_document = intensite_collection.find().sort([('_id', -1)]).limit(1)
    last_intensite_data = 0

    for entry in last_intensite_document:
        last_intensite_data = float(entry['data'])


    config_data = config_collection.find_one()
    max_value = config_data['max_value']


    last_energie_document = energie_collection.find().sort([('_id', -1)]).limit(1)
    last_energie_data = 0

    for entry in last_energie_document:
        last_energie_data = float(entry['data'])
        money = last_energie_data * 0.2

    return render_template('interface.html', labels_daily=labels_daily, data_daily=data_daily,
                           labels_monthly=labels_monthly, data_monthly=data_monthly,
                           labels_yearly=labels_yearly, data_yearly=data_yearly,
                           last_intensite_data=last_intensite_data, max_value=max_value,
                           last_energie_data=last_energie_data, money=money)
@app.route('/update_max_value', methods=['POST'])
def update_max_value():
    max_value = request.json['max_value']

    config_collection.update_one({}, {'$set': {'max_value': max_value}})
    return jsonify({'message': 'Max value updated successfully'}), 200


@app.route('/interface2')
def interface2():
    return render_template('interface2.html')


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/user_list')
def user_list():
    return render_template('user_list.html')



# Daily usage data route
@app.route('/daily_usage_data')
def daily_usage_data():
    today_date = datetime.datetime.now().strftime('%d-%m-%Y')
    today_data = puissance_collection.find({
        'date': {'$regex': '^' + today_date}
    })

    labels_daily = []
    data_daily = []
    for entry in today_data:
        labels_daily.append(entry['date'])
        data_daily.append(entry['data'])

    return jsonify({'labels': labels_daily, 'data': data_daily})




@app.route('/monthly_usage_data')
def monthly_usage_data():

    monthly_data = puissance_collection.aggregate([
        {"$group": {"_id": "$month", "total": {"$sum": {"$toInt": "$data"}}}}
    ])

    labels_monthly = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
    data_monthly = [0] * 12

    for entry in monthly_data:
        month_index = int(entry['_id']) - 1
        data_monthly[month_index] = entry['total']

    return jsonify({'labels': labels_monthly, 'data': data_monthly})




@app.route('/yearly_usage_data')
def yearly_usage_data():

    yearly_data = puissance_collection.aggregate([
        {"$group": {"_id": "$year", "total": {"$sum": {"$toInt": "$data"}}}}
    ])

    labels_yearly = ['2024', '2025', '2026', '2027']
    data_yearly = [0] * 4

    for entry in yearly_data:
        year_index = int(entry['_id']) - 2024
        data_yearly[year_index] = entry['total']

    return jsonify({'labels': labels_yearly, 'data': data_yearly})

@app.route('/last_intensite_data')
def last_intensite_data():
    last_intensite_document = intensite_collection.find().sort([('_id', -1)]).limit(1)
    last_intensite_data = 0

    for entry in last_intensite_document:
        last_intensite_data = float(entry['data'])

    return jsonify({'last_intensite_data': last_intensite_data})






@app.route('/max_value_data')
def max_value_data():

    config_data = config_collection.find_one()
    max_value = config_data['max_value']
    return jsonify({'max_value': max_value})


@app.route('/last_energie_data')
def last_energie_data():
    last_energie_document = energie_collection.find().sort([('_id', -1)]).limit(1)
    last_energie_data = 0

    for entry in last_energie_document:
        last_energie_data = float(entry['data'])

    return jsonify({'last_energie_data': last_energie_data})


if __name__ == '__main__':
    app.run(debug=True)
